<div class="main-box">
	<div class="cmdtitle">
		<a href="<?php echo base_url(); ?>Docs">document creator</a>><a href="<?php echo base_url(); ?>Categories">document categories</a>
	</div>

	<div class="main-menu row">
		  <div class="input-field col s12 m2 boxxx">
				          <input placeholder="" id="document_title" type="text" class="validate">
				          <label for="document_title">Category Name</label>
		   </div>
		   <div class="input-field col s12 m2 ">
		   	 <label for="" class="excat">Existing Categories</label>
		   </div>
	</div>
</div>