<div class="main-box">
	<div class="cmdtitle">
		<a href="<?php echo base_url(); ?>Guidelines">Guidelines</a>
	</div>

	<div class="main-menu">
		<div class="row">
			<div class="col s12 m3 textlab">
				 <label for="first_name">Search content</label>
				  <input  id="first_name" type="text" class="validate">
		    </div>
		    <div class="col s1 m1"></div>
			<div class="col s12 m8 textlab">
				<div class="content">
					Featured Pages
				</div>
			</div>
		</div>	
	</div>
</div>