<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
<div class="main-box">
    <div class="cmdtitle">
        <a href="<?php echo base_url(); ?>Report">Report & Statistics</a>
    </div>

    <div class="main-menu row">

      <div class="secrch">
      <input type="text" name="" placeholder="search" ></div>
         <div class="col s12 m3">
          <div class="rbox">
              <div class="ricon"><i class="fa fa-phone-square fa-3x theme"></i></div>
              <div class="rtitle">calls</div>
          </div>
         </div>

          <div class="col s12 m3">
          <div class="rbox">
              <div class="ricon"><i class="fa fa-paper-plane fa-3x theme"></i></div>
              <div class="rtitle">Campaigns</div>
          </div>
         </div>

          <div class="col s12 m3">
          <div class="rbox">
              <div class="ricon"><i class="far fa-edit fa-3x"></i></div>
              <div class="rtitle">ClixSign</div>
          </div>
         </div>

          <div class="col s12 m3">
          <div class="rbox">
              <div class="ricon"><i class="fas fa-exchange-alt fa-3x"></i></i></div>
              <div class="rtitle">Conversions</div>
          </div>
         </div>

         <div class="col s12 m3">
          <div class="rbox">
              <div class="ricon"><i class="fa fa-cog fa-3x theme"></i></div>
              <div class="rtitle">Data Sources</div>
          </div>
         </div>

         <div class="col s12 m3">
          <div class="rbox">
              <div class="ricon"><i class="far fa-file fa-3x"></i></div>
              <div class="rtitle">Docs</div>
          </div>
         </div>

         <div class="col s12 m3">
          <div class="rbox">
              <div class="ricon"><i class="far fa-edit fa-3x"></i></div>
              <div class="rtitle">ESign</div>
          </div>
         </div>

          <div class="col s12 m3">
          <div class="rbox">
              <div class="ricon"><i class="far fa-envelope fa-3x"></i></div>
              <div class="rtitle">email</div>
          </div>
         </div>



          <div class="col s12 m3">
          <div class="rbox">
              <div class="ricon"><i class="fas fa-calculator fa-3x"></i></div>
              <div class="rtitle">Enrollment</div>
          </div>
         </div>

         <div class="col s12 m3">
          <div class="rbox">
              <div class="ricon"><i class="fas fa-dollar-sign fa-3x"></i></div>
              <div class="rtitle">Fees</div>
          </div>
         </div>

          <div class="col s12 m3">
          <div class="rbox">
              <div class="ricon"><i class="fas fa-filter fa-3x"></i></div>
              <div class="rtitle">Funnel</div>
          </div>
         </div>



    </div>
</div>