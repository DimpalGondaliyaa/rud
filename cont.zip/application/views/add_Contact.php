<div class="main-box">
	<div class="main-menu">

		 <div class="row conrow">
		 	<div class="contacttitle">
		 		add contact
		 	</div>
		    <form class="col s12" id="contactfrm">
		      <div class="row">

		        <div class="input-field col s6 m4">
		          <input placeholder="first name" name="f_name" type="text" class="validate">
		        </div>

		         <div class="input-field col s6 m4">
		          <input placeholder="last name" name="l_name" type="text" class="validate">
		        </div>

		         <div class="input-field col s6 m4">
		          <input placeholder="user email" name="u_email" type="text" class="validate">
		        </div>

		        <div class=" col s6 m6">
		        	<label><span>Select Gender : </span>&nbsp;&nbsp;</label>
		        	<label>
				        <input name="gender" value="0" type="radio" checked />
				        <span>Male</span>
				      </label>
				      &nbsp;&nbsp;
				      <label>
				        <input name="gender" value="1" type="radio" />
				        <span>Female</span>
				      </label>
				      &nbsp;&nbsp;
				      <label>
				        <input name="gender" value="2" type="radio" />
				        <span>Other</span>
				      </label>
				</div>

		         <div class="input-field col s6 m6">
		          <input placeholder="phone" name="phone" maxlength="12" type="text" class="validate">
		        </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="mobile" name="mobile" maxlength="12" type="text" class="validate">
		        </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="income" name="income" type="text" class="validate">
		        </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="date of birth" name="dob" type="text" class="datepicker">
		        </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="address" name="address" type="text" class="validate">
		        </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="state" name="state" type="text" class="validate">
		        </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="city" name="city" type="text" class="validate">
		        </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="zipcode" name="zipcode" type="text" class="validate">
		        </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="timeofresidency" name="timeofresidency" type="text" class="validate">
		        </div>

		        <div class="input-field col s6 m6">
				<a class="waves-effect waves-light btn addcontactdata">Save</a>
				</div>
		       </div>
		   </form>
	    </div>

	</div>
</div>


<style type="text/css">
	::placeholder
	{
		text-transform: capitalize;
	}
</style>