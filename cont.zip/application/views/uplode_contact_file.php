  <div class="row">
    <form class="col s12" name="addconfilefrm" id="addconfilefrm">
      <div class="row">

        <div class="input-field col s12 m6">
          <input placeholder="file" name="file" type="file" class="validate">
        </div>

 <div class="input-field col s12 m6">
         <select id="" name="type" class="fileupload_type_select" required="">
				<option value="">--Select--</option><option value="29">ACH Authorization</option>
				<option value="Audio_Recording">Audio Recording</option>
				<option value="Bank_Statements">Bank Statements</option>
				<option value="Cancellation_Letter">Cancellation Letter</option>
				<option value="Client_Correspondence">Client Correspondence</option>
				<option value="Contract/Agreement">Contract / Agreement</option>
				<option value="CreditReport">Credit Report</option>
				<option value="Creditor_Correspondence">Creditor Correspondence</option>
				<option value="Custodial_AccountApplication">Custodial Account Application</option>
				<option value="General / Misc." selected="selected">General / Misc.</option>
				<option value="Legal Document">Legal Document</option>
				<option value="Power Of Attorney">Power Of Attorney</option>
				<option value="Settlement Letter">Settlement Letter</option>
				<option value="Statement">Statement</option>
				<option value="Voided Check">Voided Check</option>
				</select>
			</div>

         <div class="input-field col s12 m12">
          <input placeholder="description" name="description" type="text" class="validate">
        </div>

      </div>
    </form>
</div>