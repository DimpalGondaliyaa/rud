<script src="https://cdnjs.cloudflare.com/ajax/libs/jscolor/2.0.4/jscolor.min.js"></script>
<div class="main-box">
	<div class="cmdtitle">
		<a href="<?php echo base_url(); ?>Home">contact</a>  > <a href="<?php echo base_url(); ?>workflow">workflow</a>
	</div>

	<div class="main-menu">
		 <nav class="contactnav">
		    <div class="nav-wrapper connavwapp">
		      <ul id="nav-mobile" class="hide-on-med-and-down" style="position: relative;left: 5px;}">
		        <li><select><option>student loan</option></select></li>
		      </ul>
		    </div>
		  </nav>

		  <div class="wtitle">Stages / Status</div>

		  <div class="row">
		  	 <div class="col s12 m4 wbox">
		  	 	<div class="wtitlee">lead</div>
				  <ul class="wul">
				  	<li><a>follow up</a><span><input class="jscolor" value="ab2567"></span></li>
				  	<li><a>new lead</a><span><input class="jscolor" value="ab2567"></span></li>
				  	<li><a>VM 2</a><span><input class="jscolor" value="ab2567"></span></li>

				  	<li><a>VM 2</a><span><input class="jscolor" value="ab2567"></span></li>
				  	<li><a>VM 3</a><span><input class="jscolor" value="ab2567"></span></li>
				  	<li><a>docs out</a><span><input class="jscolor" value="ab2567"></span></li>
				  	<li><a>VM 1</a><span><input class="jscolor" value="ab2567"></span></li>
				  	<li><a>returned file </a><span><input class="jscolor" value="ab2567"></span></li>
				  	<li><a>do not call</a><span><input class="jscolor" value="ab2567"></span></li>
				  	<li><a>dead</a><span><input class="jscolor" value="ab2567"></span></li>
				  </ul>

				<div class="wtitlee">client</div>
				  <ul class="wul">
				  	<li><a>submitted</a><span><input class="jscolor" value="ab2567"></span></li>
				  	<li><a>approved</a><span><input class="jscolor" value="ab2567"></span></li>
				  </ul> 

				<div class="wtitlee">Underwriting</div>
				  <ul class="wul">
				  	<li><a>Enrolled/Active</a><span><input class="jscolor" value="ab2567"></span></li>
				  	<li><a>Enrolled/Paused</a><span><input class="jscolor" value="ab2567"></span></li>
				  	<li><a>Enrolled/NSF Returned</a><span><input class="jscolor" value="ab2567"></span></li>
				  	<li><a>Graduated</a><span><input class="jscolor" value="ab2567"></span></li>
				  	<li><a>Cancelled</a><span><input class="jscolor" value="ab2567"></span></li>
				  </ul>  
			</div>
		  </div>
	</div>
</div>

