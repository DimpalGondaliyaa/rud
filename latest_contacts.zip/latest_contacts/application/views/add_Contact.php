<div class="main-box">
	<div class="main-menu">

		 <div class="row conrow">
		 	<div class="contacttitle">
		 		add contact
		 	</div>
		    <form class="col s12" id="contactfrm">
		      <div class="row">

		        <div class="input-field col s6 m6">
		          <input placeholder="first name" name="f_name" type="text" class="validate">
		        </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="last name" name="l_name" type="text" class="validate">
		        </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="user email" name="u_email" type="text" class="validate">
		        </div>

		        <div class="input-field col s6 m6">
				    <select name="gender">
				      <option value="" disabled selected>Choose your gender</option>
				      <option value="0">Male</option>
				      <option value="1">Female</option>
				      <option value="2">Other</option>
				    </select>
			    </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="phone" name="phone" maxlength="12" type="text" class="validate">
		        </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="mobile" name="mobile" maxlength="12" type="text" class="validate">
		        </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="income" name="income" type="text" class="validate">
		        </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="date of birth" name="dob" type="text" class="datepicker">
		        </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="address" name="address" type="text" class="validate">
		        </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="state" name="state" type="text" class="validate">
		        </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="city" name="city" type="text" class="validate">
		        </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="zipcode" name="zipcode" type="text" class="validate">
		        </div>

		         <div class="input-field col s6 m6">
		          <input placeholder="timeofresidency" name="timeofresidency" type="text" class="validate">
		        </div>


				<a class="waves-effect waves-light btn addcontactdata">button</a>

		       </div>
		   </form>
	    </div>

	</div>
</div>


<style type="text/css">
	::placeholder
	{
		text-transform: capitalize;
	}
</style>